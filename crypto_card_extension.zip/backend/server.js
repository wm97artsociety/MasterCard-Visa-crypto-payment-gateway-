const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const cybersourceRestApi = require("cybersource-rest-client");

const app = express();
const port = 4000;

app.use(cors());
app.use(bodyParser.json());

const configObj = new cybersourceRestApi.Configuration({
  authenticationType: "http_signature",
  merchantID: "yourMerchantID",
  runEnvironment: "cybersource.environment.SANDBOX",
  merchantKeyId: "yourKeyID",
  merchantsecretKey: "yourSecret"
});

const apiClient = new cybersourceRestApi.ApiClient();
const paymentsApiInstance = new cybersourceRestApi.PaymentsApi(configObj, apiClient);

app.post("/payment", async (req, res) => {
  const { amount, crypto, cardDetails } = req.body;

  const requestObj = {
    clientReferenceInformation: { code: "crypto_buy" },
    processingInformation: { commerceIndicator: "internet" },
    paymentInformation: {
      card: {
        number: cardDetails.number,
        expirationMonth: cardDetails.expMonth,
        expirationYear: cardDetails.expYear,
        securityCode: cardDetails.cvv
      }
    },
    orderInformation: {
      amountDetails: {
        totalAmount: amount,
        currency: "USD"
      },
      billTo: {
        firstName: "John",
        lastName: "Doe",
        address1: "1 Crypto Way",
        locality: "City",
        administrativeArea: "State",
        postalCode: "12345",
        country: "US",
        email: "email@example.com",
        phoneNumber: "5551234567"
      }
    }
  };

  try {
    const response = await paymentsApiInstance.createPayment(requestObj);
    res.json({ success: true, data: response });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.listen(port, () => console.log(`Server running on port ${port}`));
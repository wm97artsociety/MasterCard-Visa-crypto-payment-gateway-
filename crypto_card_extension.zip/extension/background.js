chrome.runtime.onInstalled.addListener(() => {
  console.log("Crypto extension installed");
});
import React, { useState } from "react";

export default function App() {
  const [amount, setAmount] = useState("");
  const [crypto, setCrypto] = useState("ETH");
  const [card, setCard] = useState({ number: "", expMonth: "", expYear: "", cvv: "" });

  const handleSubmit = async () => {
    const response = await fetch("http://localhost:4000/payment", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount, crypto, cardDetails: card })
    });
    const data = await response.json();
    alert(JSON.stringify(data));
  };

  return (
    <div>
      <h1>Crypto Card Payment</h1>
      <input placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} /><br/>
      <select value={crypto} onChange={e => setCrypto(e.target.value)}>
        <option value="BTC">BTC</option>
        <option value="ETH">ETH</option>
      </select><br/>
      <input placeholder="Card Number" value={card.number} onChange={e => setCard({ ...card, number: e.target.value })} /><br/>
      <input placeholder="MM" value={card.expMonth} onChange={e => setCard({ ...card, expMonth: e.target.value })} /> /
      <input placeholder="YY" value={card.expYear} onChange={e => setCard({ ...card, expYear: e.target.value })} /><br/>
      <input placeholder="CVV" value={card.cvv} onChange={e => setCard({ ...card, cvv: e.target.value })} /><br/>
      <button onClick={handleSubmit}>Buy {crypto}</button>
    </div>
  );
}